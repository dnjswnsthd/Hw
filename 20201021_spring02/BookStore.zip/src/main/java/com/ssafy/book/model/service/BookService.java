package com.ssafy.book.model.service;

import java.util.List;
import java.util.Map;

import com.ssafy.book.model.BookDto;
import com.ssafy.util.PageNavigation;

public interface BookService {
	public void writeArticle(BookDto BookDto) throws Exception;
	public List<BookDto> listArticle(Map<String, String> map) throws Exception;
}
