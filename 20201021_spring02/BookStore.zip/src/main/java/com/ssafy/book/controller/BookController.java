package com.ssafy.book.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.book.model.BookDto;
import com.ssafy.book.model.MemberDto;
import com.ssafy.book.model.service.BookService;
import com.ssafy.util.PageNavigation;

@Controller
@RequestMapping("/article")
public class BookController {

	@Autowired
	private BookService BookService;
	
	@RequestMapping(value = "/write", method = RequestMethod.GET)
	public String write() {
		return "book/write";
	}
	
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public String write(BookDto BookDto, Model model, HttpSession session) {
		MemberDto memberDto = (MemberDto) session.getAttribute("userinfo");
		if(memberDto != null) {
			try {
				BookService.writeArticle(BookDto);
				return "book/writesuccess";
			} catch (Exception e) {
				e.printStackTrace();
				model.addAttribute("msg", "책 추가 중에 작성중 문제가 발생했습니다.");
				return "error/error";
			}
		} else {
			model.addAttribute("msg", "로그인 후 사용 가능한 페이지입니다.");
			return "error/error";
		}
	}
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(@RequestParam Map<String, String> map, Model model) {
		String spp = map.get("spp");
		map.put("spp", spp != null ? spp : "10");//sizePerPage
		try {
			List<BookDto> list = BookService.listArticle(map);
			model.addAttribute("articles", list);
			return "book/list";
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("msg", "글목록을 얻어오는 중 문제가 발생했습니다.");
			return "error/error";
		}
	}
}

