package com.ssafy.book.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.book.model.BookDto;
import com.ssafy.util.DBUtil;
@Repository
public class BookDaoImpl implements BookDao {

	@Autowired
	private DataSource dataSource;
	
	@Override
	public void writeArticle(BookDto BookDto) throws SQLException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = dataSource.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("insert into book (isbn, title, catalogue, nation, publish_date, publisher, author, price, currency, description) \n");
			insertMember.append("values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, BookDto.getIsbn());
			pstmt.setString(2, BookDto.getTitle());
			pstmt.setString(3, BookDto.getCatalogue());
			pstmt.setString(4, BookDto.getNation());
			pstmt.setString(5, BookDto.getPublish_date());
			pstmt.setString(6, BookDto.getPublisher());
			pstmt.setString(7, BookDto.getAuthor());
			pstmt.setInt(8, BookDto.getPrice());
			pstmt.setString(9, BookDto.getCurrency());
			pstmt.setString(10, BookDto.getDescription());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
	}

	@Override
	public List<BookDto> listArticle(Map<String, String> map) throws SQLException {
		List<BookDto> list = new ArrayList<BookDto>();
		
		int currentPage = Integer.parseInt(map.get("pg"));
		int sizePerPage = Integer.parseInt(map.get("spp"));
		String key = map.get("key");
		String word = map.get("word");
		
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		try {
			conn = dataSource.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select isbn, title, catalogue, nation, publish_date, publisher, author, price, currency, description \n");
			sql.append("from book \n");
			if(!word.isEmpty()) {//if(word.length() != 0) {
				if("subject".equals(key)) {
					sql.append("where subject like ? \n");
				} else {
					sql.append("where " + key + " = ? \n");
				}
			}
			sql.append("order by isbn desc \n");
			sql.append("limit ?, ?");
			pstmt = conn.prepareStatement(sql.toString());
			int idx = 0;
			if(!word.isEmpty()) {
				if("subject".equals(key))
					pstmt.setString(++idx, "%" + word + "%");
				else
					pstmt.setString(++idx, word);
			}
			pstmt.setInt(++idx, (currentPage - 1) * sizePerPage);
			pstmt.setInt(++idx, sizePerPage);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				BookDto BookDto = new BookDto();
				BookDto.setIsbn(rs.getString("isbn"));
				BookDto.setTitle(rs.getString("title"));
				BookDto.setCatalogue(rs.getString("catalogue"));
				BookDto.setNation(rs.getString("nation"));
				BookDto.setPublish_date(rs.getString("publish_date"));
				BookDto.setPublisher(rs.getString("publisher"));
				BookDto.setAuthor(rs.getString("author"));
				BookDto.setPrice(rs.getInt("price"));
				BookDto.setCurrency(rs.getString("currency"));
				BookDto.setDescription(rs.getString("description"));
				
				list.add(BookDto);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}
}
