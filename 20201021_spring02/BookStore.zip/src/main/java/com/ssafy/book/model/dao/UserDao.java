package com.ssafy.book.model.dao;

import java.sql.SQLException;
import java.util.Map;

import com.ssafy.book.model.MemberDto;

public interface UserDao {

	public MemberDto login(Map<String, String> map) throws SQLException;
	
}
