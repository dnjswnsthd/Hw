package com.ssafy.book.model.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.book.model.BookDto;

public interface BookDao {
	public void writeArticle(BookDto guestBookDto) throws SQLException;
	public List<BookDto> listArticle(Map<String, String> map) throws SQLException;
}
