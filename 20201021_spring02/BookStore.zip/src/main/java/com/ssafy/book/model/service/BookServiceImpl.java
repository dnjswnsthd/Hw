package com.ssafy.book.model.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.book.model.BookDto;
import com.ssafy.book.model.dao.BookDao;
import com.ssafy.util.PageNavigation;
@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookDao BookDao;

	@Override
	public void writeArticle(BookDto BookDto) throws Exception {
		if(BookDto.getIsbn() == null || BookDto.getTitle() == null || BookDto.getCatalogue() == null || BookDto.getNation() == null
				|| BookDto.getPublish_date() == null || BookDto.getPublisher() == null || BookDto.getAuthor() == null || BookDto.getPrice() == 0
				|| BookDto.getCurrency() == null || BookDto.getDescription() == null) {
			throw new Exception();
		}
		BookDao.writeArticle(BookDto);
	}

	@Override
	public List<BookDto> listArticle(Map<String, String> map) throws Exception {
		map.put("key", map.get("key") == null ? "" : map.get("key"));
		map.put("word", map.get("word") == null ? "" : map.get("word"));
		return BookDao.listArticle(map);
	}
}
