package com.ssafy.test;

public class BeanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
