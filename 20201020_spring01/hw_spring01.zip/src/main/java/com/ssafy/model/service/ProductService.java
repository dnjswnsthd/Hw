package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;

public interface ProductService {
	public ProductRepo getRepo() throws SQLException;
	public List<ProductRepo> selectAll() throws SQLException;
	public Product select(String id) throws SQLException;
	public int insert(Product product) throws SQLException;
	public int update(Product product) throws SQLException;
	public int delete(String id) throws SQLException;
}
