package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dto.Product;
import com.ssafy.model.repository.ProductRepo;

public class ProductServiceImpl implements ProductService {

	@Override
	public ProductRepo getRepo() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProductRepo> selectAll() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product select(String id) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert(Product product) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Product product) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int delete(String id) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

}
