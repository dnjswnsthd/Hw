package com.ssafy.book.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ssafy.book.model.Member;
import com.ssafy.book.model.Product;
import com.ssafy.book.model.service.LoginService;
import com.ssafy.book.model.service.LoginServiceImpl;
import com.ssafy.book.model.service.RegisterService;
import com.ssafy.book.model.service.RegisterServiceImpl;
import com.ssafy.book.model.service.SearchService;
import com.ssafy.book.model.service.SearchServiceImpl;


/**
 * Servlet implementation class MainServlet
 */
@WebServlet("/main.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private LoginService loginService;
	private RegisterService registerService;
       
    public MainServlet() {
        super();
    }
    
    @Override
	public void init() throws ServletException {
		super.init();
		loginService = new LoginServiceImpl();
		registerService = new RegisterServiceImpl();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}

	private void process(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String root = request.getContextPath();
		
		String act = request.getParameter("act");
		
		if("login".equals(act)) {
			login(request, response);
		} else if("logout".equals(act)) {
			logout(request, response);
		} else if("register".equals(act)) {
			register(request, response);
		} else if("view".equals(act)) {
			view(request, response);
		} else if("list".equals(act)) {
			list(request, response);
		}
		
	}
	private void list(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String path = "/BookList.jsp";
		String num = request.getParameter("num");
		SearchService service = new SearchServiceImpl();
		List<Product> products = service.searchAll();
		request.setAttribute("Products", products);
		request.getRequestDispatcher(path).forward(request, response);
	}
	
	private void view(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String path = "/BookView.jsp";
		String num = request.getParameter("num");
		SearchService service = new SearchServiceImpl();
		Product vo = new Product();
		vo.setNum(num);
		service.search(vo);
		System.out.println(vo);
		request.setAttribute("Product", vo);
		request.getRequestDispatcher(path).forward(request, response);
	}
	
	private void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		HttpSession session = request.getSession();
		session.removeAttribute("userinfo");
//		session.invalidate();
		response.sendRedirect(request.getContextPath() + "/Login.html");
	}
	
	private void login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/Cookie.jsp";
		String userid = request.getParameter("userid");
		String userpwd = request.getParameter("userpwd");
		
		try {
			Member memberDto = loginService.login(userid, userpwd);
			System.out.println(memberDto.getId() + "  " + memberDto.getPw());
			
			if(memberDto != null) {
//				session 설정
				HttpSession session = request.getSession();
				session.setAttribute("userinfo", memberDto);
				
			} else {
				request.setAttribute("msg", "아이디 또는 비밀번호 확인 후 로그인해 주세요.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "로그인 중 문제가 발생했습니다.");
			path = "/error/error.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
	}
	
	private void register(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = "/Book.html";
		String num = request.getParameter("productNum");
		String name = request.getParameter("productName");
		int price = Integer.parseInt(request.getParameter("price"));
		String description = request.getParameter("description");
		
		Product product = new Product();
		product.setNum(num);
		product.setName(name);
		product.setPrice(price);
		product.setDescription(description);
		
		try {
			System.out.println(product);
			registerService.register(product);
			
//			현재 있는 쿠키 모두 삭제
			Cookie[] cookies = request.getCookies();
			for(int i = 0; i < cookies.length; i++) {
				cookies[i].setMaxAge(0);
				response.addCookie(cookies[i]);
			}
			// 쿠키 생성
			Cookie numCookie = new Cookie("num", num);
			Cookie nameCookie = new Cookie("name", name);
			Cookie priceCookie = new Cookie("price", Integer.toString(price));
			Cookie descriptionCookie = new Cookie("description", description);
			numCookie.setPath(request.getContextPath());
			nameCookie.setPath(request.getContextPath());
			priceCookie.setPath(request.getContextPath());
			descriptionCookie.setPath(request.getContextPath());
			// 쿠기 40년간 저장
			numCookie.setMaxAge(365 * 24 * 60 * 60 * 40);
			nameCookie.setMaxAge(365 * 24 * 60 * 60 * 40);
			priceCookie.setMaxAge(365 * 24 * 60 * 60 * 40);
			descriptionCookie.setMaxAge(365 * 24 * 60 * 60 * 40);
			// 쿠키 추가
			response.addCookie(numCookie);
			response.addCookie(nameCookie);
			response.addCookie(priceCookie);
			response.addCookie(descriptionCookie);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "상품 등록 중 문제가 발생하였습니다.");
			path = "/error/error.jsp";
		}
		request.getRequestDispatcher(path).forward(request, response);
		
	}
	
}
