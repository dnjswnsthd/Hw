package com.ssafy.book.model.service;

import com.ssafy.book.model.Member;

public interface LoginService {

	public Member login(String userid, String userpwd) throws Exception;
	
}
