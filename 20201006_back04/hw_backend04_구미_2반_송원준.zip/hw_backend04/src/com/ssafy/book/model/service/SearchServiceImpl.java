package com.ssafy.book.model.service;

import java.util.List;

import com.ssafy.book.model.Product;
import com.ssafy.book.model.dao.SearchDAO;
import com.ssafy.book.model.dao.SearchDAOImpl;

public class SearchServiceImpl implements SearchService {
	SearchDAO searchDAO;
	
	public SearchServiceImpl() {
		searchDAO = new SearchDAOImpl();
	}

	@Override
	public List<Product> search() {
		return searchDAO.search();
	}

	@Override
	public List<Product> search(String name) {
		return searchDAO.search(name);
	}

	@Override
	public List<Product> search(int price) {
		return searchDAO.search(price);
	}
	
}
