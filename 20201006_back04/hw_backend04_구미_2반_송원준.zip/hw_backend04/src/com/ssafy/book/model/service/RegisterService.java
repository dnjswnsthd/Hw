package com.ssafy.book.model.service;

import java.sql.SQLException;

import com.ssafy.book.model.Product;

public interface RegisterService {
	public void register(Product product) throws SQLException;
}
