package com.ssafy.book.model.dao;

import java.util.List;

import com.ssafy.book.model.Product;

public interface SearchDAO {
	public List<Product> searchAll();
	public void search(Product vo);
}
