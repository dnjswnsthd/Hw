package com.ssafy.book.model.dao;

import java.util.List;

import com.ssafy.book.model.Product;

public interface SearchDAO {
	public List<Product> search();
	public List<Product> search(String name);
	public List<Product> search(int price);
}
