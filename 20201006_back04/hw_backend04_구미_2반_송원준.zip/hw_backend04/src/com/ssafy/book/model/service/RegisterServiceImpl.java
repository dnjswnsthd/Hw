package com.ssafy.book.model.service;

import java.sql.SQLException;

import com.ssafy.book.model.Product;
import com.ssafy.book.model.dao.RegisterDAO;
import com.ssafy.book.model.dao.RegisterDAOImpl;

public class RegisterServiceImpl implements RegisterService {
	RegisterDAO registerDAO;
	
	public RegisterServiceImpl() {
		registerDAO = new RegisterDAOImpl();
	}

	@Override
	public void register(Product product) throws SQLException {
		registerDAO.register(product);
	}

}
