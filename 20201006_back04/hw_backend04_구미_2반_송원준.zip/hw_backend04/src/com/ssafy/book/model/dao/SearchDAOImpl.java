package com.ssafy.book.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.book.model.Product;
import com.ssafy.book.util.DBUtil;

public class SearchDAOImpl implements SearchDAO {
	private final String searchAllsql = "select * from product";
	private final String searchsql = "select num, name, price, description from product where num = ?";

	@Override
	public List<Product> searchAll() {
		List<Product> list = new ArrayList<Product>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(searchAllsql);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setNum(rs.getString("num"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));
				
				list.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}

	@Override
	public void search(Product vo) {
		Connection conn = null;
		PreparedStatement psmt = null;
		ResultSet rst = null;
		try {
			conn = DBUtil.getConnection();
			psmt = conn.prepareStatement(searchsql);
			psmt.setString(1, vo.getNum());
			rst = psmt.executeQuery();
		
			if (rst.next()) {
				vo.setNum(rst.getString(1));
				vo.setName(rst.getString(2));
				vo.setPrice(rst.getInt(3));
				vo.setDescription(rst.getString(4));
			}
		} catch (SQLException e) {
			System.out.println("한개 읽기 : " + e);
		} finally {
			DBUtil.close(rst);
			DBUtil.close(psmt);
			DBUtil.close(conn);
		}
	}

}
