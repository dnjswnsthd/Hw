package com.ssafy.book.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ssafy.book.model.Product;
import com.ssafy.book.util.DBUtil;

public class SearchDAOImpl implements SearchDAO {
	private final String searchAllQuery = "select * from product";
	private final String searchNameQuery = "select * from product where name like ?";
	private final String searchPriceQuery = "select * from product where price < ?";

	@Override
	public List<Product> search() {
		List<Product> list = new ArrayList<Product>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(searchAllQuery);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setNum(rs.getString("num"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));
				
				list.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}

	@Override
	public List<Product> search(String name) {
		List<Product> list = new ArrayList<Product>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(searchNameQuery);
			pstmt.setString(1, "%" + name + "%");
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setNum(rs.getString("num"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));

				list.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}

	@Override
	public List<Product> search(int price) {
		List<Product> list = new ArrayList<Product>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(searchPriceQuery);
			pstmt.setInt(1, price);
			
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Product product = new Product();
				product.setNum(rs.getString("num"));
				product.setName(rs.getString("name"));
				product.setPrice(rs.getInt("price"));
				product.setDescription(rs.getString("description"));
				System.out.println(product);
				list.add(product);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		
		return list;
	}

}
