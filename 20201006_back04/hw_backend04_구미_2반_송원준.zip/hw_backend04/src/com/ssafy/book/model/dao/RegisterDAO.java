package com.ssafy.book.model.dao;

import java.sql.SQLException;

import com.ssafy.book.model.Product;

public interface RegisterDAO {
	public void register(Product product) throws SQLException;
}
