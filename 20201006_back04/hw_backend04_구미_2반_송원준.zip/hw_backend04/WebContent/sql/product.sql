use ssafyweb;

create table member (
	id varchar(20) primary key, 
	pw varchar(20) NOT NULL
);

insert into member values ('ssafy', 'ssafy');

create table product (
	num varchar(20) primary key,
    name varchar(20) not null,
    price int not null,
    description varchar(100) not null
);
