package com.ssafy.book.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.ssafy.book.model.BookDto;

public interface BookService {
	public void insertBook(BookDto dto) throws SQLException;
	public List<BookDto> selectBook(Map<String, String> map) throws SQLException;
	public BookDto selectIsbn(String isbn) throws SQLException;
	public void deleteIsbn(String isbn) throws SQLException;
}
