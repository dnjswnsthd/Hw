package com.ssafy.book;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HwBookSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HwBookSpringbootApplication.class, args);
	}

}
