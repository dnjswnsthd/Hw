export default {
  template: `
    <p>
      <router-link to="/">HOME</router-link>
      <router-link to="/list">게시판</router-link>
    </p>  
  `,
};
