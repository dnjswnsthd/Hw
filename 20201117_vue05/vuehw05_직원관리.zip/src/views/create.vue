<template>
  <div>
      <h2>회원 등록</h2>
    <table class="tb">
      <tr>
        <td class="table-primary">이름</td>
        <td><input ref="name" type="text" placeholder="이름을 입력하세요" v-model="name"></td>
      </tr>
      <tr>
        <td class="table-primary">이메일</td>
        <td><input ref="mailid" type="text" v-model="mailid"></td>
      </tr>
      <tr>
        <td class="table-primary">고용일</td>
        <td><input ref="start_date" type="date" v-model="start_date"></td>
      </tr>
      <tr>
        <td class="table-primary">관리자</td>
        <td><input ref="manager_id" type="text" v-model="manager_id"></td>
      </tr>
      <tr>
        <td class="table-primary">직책</td>
        <td><input ref="title" type="text" v-model="title"></td>
      </tr>
      <tr>
        <td class="table-primary">부서</td>
        <td><input ref="dept_id" type="text" v-model="dept_id"></td>
      </tr>
      <tr>
        <td class="table-primary">월급</td>
        <td><input ref="salary" type="number" v-model="salary"></td>
      </tr>
      <tr>
        <td class="table-primary">커미션</td>
        <td><input ref="commission_pct" type="number" v-model="commission_pct"></td>
      </tr>
    </table>
    <div class="tb">
      <button class="btn btn-primary" @click="checkHandler">등록</button>
      <button class="btn btn-primary" @click="moveList">취소</button>
    </div>
  </div>
</template>
<script>
import axios from "axios";
export default {
  name: 'create',
  data: function() {
    return {
      name: '',
      mailid: '',
      start_date: '',
      manager_id: '',
      title: '',
      dept_id: '',
      salary: '',
      commission_pct: '',
    };
  },
  methods: {
    checkHandler() {
      let err = true;
      let msg = '';
      !this.name &&
        ((msg = '이름를 입력해주세요'),
        (err = false),
        this.$refs.name.focus());
      err &&
        !this.mailid &&
        ((msg = '이메일을 입력해주세요'), (err = false), this.$refs.title.focus());
      err &&
        !this.start_date &&
        ((msg = '고용일을 입력해주세요'),
        (err = false),
        this.$refs.start_date.focus());
    err &&
        !this.title &&
        ((msg = '직책을 입력해주세요'),
        (err = false),
        this.$refs.start_date.focus());
    err &&
        !this.dept_id &&
        ((msg = '부서을 입력해주세요'),
        (err = false),
        this.$refs.start_date.focus());
    err &&
        !this.salary &&
        ((msg = '월급을 입력해주세요'),
        (err = false),
        this.$refs.start_date.focus());
      if (!err) alert(msg);
      else this.createHandler();
    },
    createHandler() {
      axios
        .post('http://localhost:8097/hrmboot/api/employee', {
          name: this.name,
          mailid: this.mailid,
          start_date: this.start_date,
          manager_id: this.manager_id,
          title: this.title,
          dept_id: this.dept_id,
          salary: this.salary,
          commission_pct: this.commission_pct,
        })
        .then(({ data }) => {
          let msg = '등록 처리시 문제가 발생했습니다.';
          if (data.state === 'succ') {
            msg = '등록이 완료되었습니다.';
          }
          alert(msg);
          this.moveList();
        })
        .catch(() => {
          alert('등록 처리시 에러가 발생했습니다.');
        });
    },
    moveList() {
      this.$router.push('/');
    },
  },
};
</script>
