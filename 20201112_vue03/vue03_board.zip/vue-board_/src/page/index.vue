<template>
  <div>
    <div>
      <h1 class="text-center">메인페이지</h1>
    </div>
    <div>만든이 : 송원준</div>
  </div>
</template>

<script>
export default {
  name: "index",
  components: {}
};
</script>

<style>
</style>
