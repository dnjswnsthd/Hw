package com.ssafy.book.model.service;

import com.ssafy.book.model.Member;
import com.ssafy.book.model.dao.LoginDao;
import com.ssafy.book.model.dao.LoginDaoImpl;

public class LoginServiceImpl implements LoginService {

	LoginDao loginDao;
	
	public LoginServiceImpl() {
		loginDao = new LoginDaoImpl();
	}
	
	@Override
	public Member login(String userid, String userpwd) throws Exception {
		if(userid == null || userpwd == null)
			return null;
		return loginDao.login(userid, userpwd);
	}

}
