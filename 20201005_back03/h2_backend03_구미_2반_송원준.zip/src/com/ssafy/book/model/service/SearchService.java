package com.ssafy.book.model.service;

import java.util.List;

import com.ssafy.book.model.Product;

public interface SearchService {
	public List<Product> search();
}
