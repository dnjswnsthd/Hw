package com.ssafy.book.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.ssafy.book.model.Member;
import com.ssafy.book.util.DBUtil;

public class LoginDaoImpl implements LoginDao {
	private final String selectQuery = "select id, pw from member where id=? and pw=?";

	@Override
	public Member login(String userid, String userpwd) throws SQLException {
		Member member = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			pstmt = conn.prepareStatement(selectQuery);
			pstmt.setString(1, userid);
			pstmt.setString(2, userpwd);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				member = new Member();
				member.setId(rs.getString("id"));
				member.setPw(rs.getString("pw"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
			member = null;
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return member;
	}

}
