package com.ssafy.book.model.dao;

import java.sql.SQLException;

import com.ssafy.book.model.Member;

public interface LoginDao {

	public Member login(String userid, String userpwd) throws SQLException;
	
}
