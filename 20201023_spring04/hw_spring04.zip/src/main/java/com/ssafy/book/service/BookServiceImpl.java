package com.ssafy.book.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssafy.book.dao.BookDao;
import com.ssafy.book.model.BookDto;

@Service
public class BookServiceImpl implements BookService {
	@Autowired
	private SqlSession sqlSession;
	@Override
	public void insertBook(BookDto dto) throws SQLException {
		sqlSession.getMapper(BookDao.class).insertBook(dto);
	}
	
	@Override
	public List<BookDto> selectBook(Map<String, String> map) throws SQLException {
		Map<String, String> param = new HashMap<String, String>();
		param.put("searchType", map.get("searchType") == null ? "" : map.get("searchType"));
		param.put("searchWord", map.get("searchWord") == null ? "" : map.get("searchWord"));
		return sqlSession.getMapper(BookDao.class).selectBook(param);
	}
	@Override
	public BookDto selectIsbn(String isbn) throws SQLException {
		return sqlSession.getMapper(BookDao.class).selectIsbn(isbn);
	}
	@Override
	public void deleteIsbn(String isbn) throws SQLException {
		sqlSession.getMapper(BookDao.class).deleteIsbn(isbn);
	}
}
