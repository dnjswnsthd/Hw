package com.ssafy.book.controller;

import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssafy.book.model.BookDto;
import com.ssafy.book.service.BookService;

@Controller
public class BookController {
	@Autowired
	private BookService bookService;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		return "home";
	}
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public String insert(BookDto dto, Model model) {
		System.out.println(dto);
		try {
			bookService.insertBook(dto);
			model.addAttribute("msg", "정상적으로 도서를 DB에 저장했습니다.");
		} catch (SQLException e) {
			e.printStackTrace();
			model.addAttribute("msg", "DB에 도서 추가에 실패하였습니다");
			return "home";
		}
		return "result";
	}
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public String list(@RequestParam Map<String, String> map, Model model) {
		try {
			List<BookDto> list = bookService.selectBook(map);
			model.addAttribute("list", list);
		} catch (SQLException e) {
			e.printStackTrace();
			model.addAttribute("msg", "글목록을 얻어오는 중 문제가 발생했습니다.");
		}
		return "list_Book";
	}
	@RequestMapping(value = "/view", method = RequestMethod.GET)
	public String bookView(@RequestParam("isbn")String isbn, Model model) {
		BookDto dto = null;
		try {
			dto = bookService.selectIsbn(isbn);
		} catch (SQLException e) {
			e.printStackTrace();
			model.addAttribute("msg", "해당 도서를 찾을 수 없습니다");
			return "result";
		}
		model.addAttribute("book", dto);
		return "view_Book";
	}
	
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String delete(@RequestParam("isbn")String isbn, Model model) {
		try {
			bookService.deleteIsbn(isbn);
			model.addAttribute("msg", "정상적으로 삭제 되었습니다");
		} catch (SQLException e) {
			e.printStackTrace();
			model.addAttribute("msg", "도서 삭제에 실패했습니다");
		}
		
		return "result";
	}
}
