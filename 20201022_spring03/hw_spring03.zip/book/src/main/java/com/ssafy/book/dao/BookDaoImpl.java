package com.ssafy.book.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ssafy.book.model.BookDto;
import com.ssafy.util.SqlMapConfig;

@Repository
public class BookDaoImpl implements BookDao {
	@Autowired
	private DataSource ds;
	
	@Override
	public void insertBook(BookDto dto) throws SQLException {
		try(SqlSession sqlSession = SqlMapConfig.getSqlSession()) {
			sqlSession.insert("com.ssafy.book.dao.BookDao.insertBook", dto);
		}
	}

	@Override
	public List<BookDto> selectBook(Map<String, String> map) throws SQLException {
		try(SqlSession sqlSession = SqlMapConfig.getSqlSession()) {
			return sqlSession.selectList("com.ssafy.book.dao.BookDao.selectBook", map);
		}
	}

	// isbn으로 상세 정보 불러오기
	@Override
	public BookDto selectIsbn(String isbn) throws SQLException {
		try(SqlSession sqlSession = SqlMapConfig.getSqlSession()) {
			return sqlSession.selectOne("com.ssafy.book.dao.BookDao.selectIsbn", isbn);
		}
	}
	//Isbn으로 삭제하기
	@Override
	public void deleteIsbn(String isbn) throws SQLException {
		try(SqlSession sqlSession = SqlMapConfig.getSqlSession()) {
			sqlSession.delete("com.ssafy.book.dao.BookDao.deleteIsbn", isbn);
		}
	}
}
