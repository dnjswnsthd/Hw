package com.ssafy.model.dao;

import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import com.ssafy.model.ProductDto;

public interface ProductDao {
	public void writeProduct(ProductDto productDto) throws SQLException, NamingException;
	public List<ProductDto> listProduct(String key, String word) throws SQLException, NamingException;
	
	public ProductDto getProduct(String pdno) throws SQLException, NamingException;
	public void modifyProduct(ProductDto productDto) throws SQLException, NamingException;
	public void deleteProduct(String pdno) throws SQLException, NamingException;
}
