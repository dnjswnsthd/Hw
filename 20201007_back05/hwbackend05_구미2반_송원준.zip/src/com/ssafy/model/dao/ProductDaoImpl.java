package com.ssafy.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.NamingException;

import com.ssafy.model.ProductDto;
import com.ssafy.util.DBUtil;

public class ProductDaoImpl implements ProductDao {

	@Override
	public void writeProduct(ProductDto productDto) throws SQLException, NamingException {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			
			insertMember.append("insert into product (userid, pdno, pdname, pdprice, pdexplain, regtime) values (?, ?, ?, ?, ?, now())");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, productDto.getUserid());
			pstmt.setString(2, productDto.getPdno());
			pstmt.setString(3, productDto.getPdname());
			pstmt.setString(4, productDto.getPdprice());
			pstmt.setString(5, productDto.getPdexplain());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}

	}

	@Override
	public List<ProductDto> listProduct(String key, String word) throws SQLException, NamingException {
		List<ProductDto> list = new ArrayList<ProductDto>();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select userid, pdno, pdname, pdprice, pdexplain, regtime \n");
			sql.append("from product \n");
			if (!word.isEmpty()) {
				if ("pdname".equals(key)) {
					sql.append("where pdname like ? \n");
				} else {
					sql.append("where " + key + " = ? \n");
				}
			}
			sql.append("order by pdno desc \n");
			pstmt = conn.prepareStatement(sql.toString());
			if (!word.isEmpty()) {
				if ("pdname".equals(key))
					pstmt.setString(1, "%" + word + "%");
				else
					pstmt.setString(1, word);
			}
			rs = pstmt.executeQuery();
			while (rs.next()) {
				ProductDto productDto = new ProductDto();
				productDto.setUserid(rs.getString("userid"));
				productDto.setPdno(rs.getString("pdno"));
				productDto.setPdname(rs.getString("pdname"));
				productDto.setPdprice(rs.getString("pdprice"));
				productDto.setPdexplain(rs.getString("pdexplain"));
				productDto.setRegtime(rs.getString("regtime"));
				list.add(productDto);
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}

		return list;
	}

	@Override
	public ProductDto getProduct(String pdno) throws SQLException, NamingException {
		ProductDto productDto = null;

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			conn = DBUtil.getConnection();
			StringBuilder sql = new StringBuilder();
			sql.append("select userid, pdno, pdname, pdprice, pdexplain, regtime \n");
			sql.append("from product \n");
			sql.append("where pdno = ?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, pdno);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				productDto = new ProductDto();
				productDto.setUserid(rs.getString("userid"));
				productDto.setPdno(rs.getString("pdno"));
				productDto.setPdname(rs.getString("pdname"));
				productDto.setPdprice(rs.getString("pdprice"));
				productDto.setPdexplain(rs.getString("pdexplain"));
				productDto.setRegtime(rs.getString("regtime"));
			}
		} finally {
			DBUtil.close(rs);
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}
		return productDto;
	}

	@Override
	public void modifyProduct(ProductDto productDto) throws SQLException, NamingException {
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("update product \n");
			insertMember.append("set pdname = ?, pdexplain = ? \n");
			insertMember.append("where pdno = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, productDto.getPdname());
			pstmt.setString(2, productDto.getPdexplain());
			pstmt.setString(3, productDto.getPdno());
			System.out.println(productDto.getPdname() + " " + productDto.getPdexplain() + " " + productDto.getPdno());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}

	}

	@Override
	public void deleteProduct(String pdno) throws SQLException, NamingException {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder insertMember = new StringBuilder();
			insertMember.append("delete from product \n");
			insertMember.append("where pdno = ?");
			pstmt = conn.prepareStatement(insertMember.toString());
			pstmt.setString(1, pdno);
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt);
			DBUtil.close(conn);
		}

	}

}
