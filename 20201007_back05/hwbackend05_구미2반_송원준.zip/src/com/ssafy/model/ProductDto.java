package com.ssafy.model;

public class ProductDto {

	private String userid;
	private String pdno;
	private String pdname;
	private String pdprice;
	private String pdexplain;
	private String regtime;
	public String getUserid() {
		System.out.println("pd " + userid);
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPdno() {
//		System.out.println(pdno);
		return pdno;
	}
	public void setPdno(String pdno) {
		this.pdno = pdno;
		
	}
	public String getPdname() {
//		System.out.println(pdname);
		return pdname;
	}
	public void setPdname(String pdname) {
		this.pdname = pdname;
	}
	public String getPdprice() {
//		System.out.println(pdprice);
		return pdprice;
	}
	public void setPdprice(String pdprice) {
		this.pdprice = pdprice;
	}
	public String getPdexplain() {
//		System.out.println(pdexplain);
		return pdexplain;
	}
	public void setPdexplain(String pdexplain) {
		this.pdexplain = pdexplain;
	}
	public String getRegtime() {
		return regtime;
	}
	public void setRegtime(String regtime) {
		this.regtime = regtime;
	}
	
	
	
	
}
