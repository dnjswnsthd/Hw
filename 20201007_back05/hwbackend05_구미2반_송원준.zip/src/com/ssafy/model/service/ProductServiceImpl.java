package com.ssafy.model.service;

import java.sql.SQLException;
import java.util.List;

import javax.naming.NamingException;

import com.ssafy.model.ProductDto;
import com.ssafy.model.dao.ProductDao;
import com.ssafy.model.dao.ProductDaoImpl;

public class ProductServiceImpl implements ProductService{

	private ProductDao productDao;
	
	public ProductServiceImpl() {
		productDao = new ProductDaoImpl();
	}
	
	@Override
	public void writeProduct(ProductDto productDto) throws Exception {
		if(productDto.getPdname() == null || productDto.getPdexplain() == null) {
			throw new Exception();
		}
		productDao.writeProduct(productDto);
		
	}

	@Override
	public List<ProductDto> listProduct(String key, String word) throws SQLException, NamingException {
		key = key == null ? "" : key;
		word = word == null ? "" : word;
		return productDao.listProduct(key, word);
	}

	@Override
	public ProductDto getProduct(String pdno) throws SQLException , NamingException{
		return productDao.getProduct(pdno);
	}

	@Override
	public void modifyProduct(ProductDto productDto) throws SQLException , NamingException{
		productDao.modifyProduct(productDto);
		
	}

	@Override
	public void deleteProduct(String pdno) throws SQLException , NamingException{
		productDao.deleteProduct(pdno);
		
	}


}
