<template>
  <div>
      <h2>사원 목록</h2>
    <table class="tb"> 
        <thead>
            <tr class="table-primary">
               <th>사원 아이디</th>
               <th>사원명</th>
               <th>부서명</th>
               <th>직책</th>
               <th>월급</th> 
            </tr>
        </thead>
      <tr v-for="(item, index) in items" :key="index">
        <td>{{ item.id }}</td>
        <td>{{ item.name}}</td>
        <td>{{item.dept_name}}</td>
        <td>{{item.title}}</td>
        <td>{{item.salary}}</td>
      </tr>
    </table>
  </div>
</template>

<script>
import aixos from 'axios';
export default {
  name: 'list',
  data() {
    return {
      items: [],
    };
  },
  created() {
    aixos.get('http://localhost:8097/hrmboot/api/employee/all').then(
      ({ data }) => {
        this.items = data;
      }
    );
  },
};
</script>
